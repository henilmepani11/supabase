package com.example.supa_practice_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
