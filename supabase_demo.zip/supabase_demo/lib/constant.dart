import 'package:flutter/material.dart';

class MyBorder {
  static get outlineInputBorder =>
      const OutlineInputBorder(borderSide: BorderSide(color: Colors.black));
}
