import 'package:flutter/material.dart';
import 'package:supa_practice_project/constant.dart';
import 'package:supa_practice_project/screen/home_screen/provider/home_provider.dart';

Future<void> myDialog(
    {context,
    TextEditingController? name,
    TextEditingController? descripation,
    id,
    userId,
    HomeProvider? value,
    isAdd}) async {
  return showDialog(
    context: context,
    builder: (BuildContext context) {
      isAdd ? name?.clear() : null;
      isAdd ? descripation?.clear() : null;
      return AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                controller: name,
                decoration: InputDecoration(
                  hintText: "Enter Name",
                  focusedBorder: MyBorder.outlineInputBorder,
                  border: MyBorder.outlineInputBorder,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                controller: descripation,
                decoration: InputDecoration(
                  hintText: "Enter descripation",
                  focusedBorder: MyBorder.outlineInputBorder,
                  border: MyBorder.outlineInputBorder,
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            child: Text(isAdd ? 'Add Note' : "Edit Note"),
            onPressed: () {
              isAdd
                  ? value?.addData(context, id: userId)
                  : value?.editData(context, id: id);
            },
          ),
        ],
      );
    },
  );
}
