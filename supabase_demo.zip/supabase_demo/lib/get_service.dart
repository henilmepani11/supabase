import 'package:get_storage/get_storage.dart';

class GetService {
  final box = GetStorage();

  setLogin(id) {
    box.write('key', id);
  }

  getLogin() {
    return box.read('key');
  }
}
