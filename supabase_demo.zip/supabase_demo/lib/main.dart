import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:provider/provider.dart';
import 'package:supa_practice_project/get_service.dart';
import 'package:supa_practice_project/screen/chat_screen/provider/chat_provider.dart';
import 'package:supa_practice_project/screen/home_screen/provider/home_provider.dart';
import 'package:supa_practice_project/screen/home_screen/view/home_screen.dart';
import 'package:supa_practice_project/screen/login_screen/provider/login_provider.dart';
import 'package:supa_practice_project/screen/login_screen/view/login_screen.dart';
import 'package:supa_practice_project/screen/signup_screen/provider/signup_provider.dart';
import 'package:supa_practice_project/supabase_constant_key.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() async {
  await GetStorage.init();
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: SupabaseCredentials.apiUrl,
    anonKey: SupabaseCredentials.apiKey,
  );
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LoginProvider()),
        ChangeNotifierProvider(create: (_) => SignUpProvider()),
        ChangeNotifierProvider(create: (_) => HomeProvider()),
        ChangeNotifierProvider(create: (_) => ChatProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  GetService getService = GetService();

  @override
  Widget build(BuildContext context) {
    var value = getService.getLogin();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: value != null ? const HomeScreen() : const LoginScreen(),
    );
  }
}
