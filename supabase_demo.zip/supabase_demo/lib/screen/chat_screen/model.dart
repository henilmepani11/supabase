class MesseagesModel {
  int? id;
  String? createdAt;
  String? updatedAt;
  String? messagesText;
  String? chatId;
  String? receiverId;
  String? senderId;

  MesseagesModel(
      {this.id,
      this.senderId,
      this.createdAt,
      this.messagesText,
      this.chatId,
      this.receiverId,
      this.updatedAt});

  MesseagesModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    senderId = json['sender_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    messagesText = json['messages_text'];
    chatId = json['chat_id'];
    receiverId = json['receiver_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['messages_text'] = messagesText;
    data['sender_id'] = senderId;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['chat_id'] = chatId;
    data['receiver_id'] = receiverId;
    return data;
  }
}
