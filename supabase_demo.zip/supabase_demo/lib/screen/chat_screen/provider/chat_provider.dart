import 'package:flutter/material.dart';
import 'package:supa_practice_project/get_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatProvider extends ChangeNotifier {
  TextEditingController chatController = TextEditingController();

  GetService getService = GetService();
  String receiver_id = "c3734a1e-635d-4c49-86c6-96c42ae50fb6";

  Future<void> addMessages() async {
    try {
      await Supabase.instance.client.from('messages').insert({
        'messages_text': chatController.text,
        'created_at': DateTime.now().toIso8601String(),
        "updated_at": DateTime.now().toIso8601String(),
        'id': int.tryParse(DateTime.now().millisecondsSinceEpoch.toString()),
        'chat_id': generatechatId(getService.getLogin(), receiver_id),
        'sender_id': getService.getLogin(),
        'receiver_id': receiver_id,
      });
      chatController.clear();

      notifyListeners();
    } catch (e) {
      print("addMessages :$e");
    }
  }

  String generatechatId(String senderId, String receiverId) {
    if (senderId.codeUnits[0] > receiverId.codeUnits[0]) {
      return "${senderId}_$receiverId";
    } else {
      return "${receiverId}_$senderId";
    }
  }

  setField() {
    chatController.clear();
  }
}
