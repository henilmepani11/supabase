import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supa_practice_project/screen/chat_screen/model.dart';
import 'package:supa_practice_project/screen/chat_screen/provider/chat_provider.dart';
import 'package:supa_practice_project/supabase_constant_key.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  @override
  void initState() {
    ChatProvider chatProvider =
        Provider.of<ChatProvider>(context, listen: false);
    chatProvider.setField();

    // SupabaseCredentials.supabaseClient
    //     .from('messages')
    //     .stream(primaryKey: ['id'])
    //     .eq(
    //         "chat_id",
    //         chatProvider.generatechatId(
    //             chatProvider.getService.getLogin(), chatProvider.receiver_id))
    //     .listen((event) {
    //       print("listen");
    //       print(event);
    //     });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ChatProvider>(
      builder: (context, value, child) {
        return GestureDetector(
          onTap: () {
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            appBar: AppBar(title: const Text("Chat screen"), centerTitle: true),
            body: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                StreamBuilder(
                    stream: SupabaseCredentials.supabaseClient
                        .from("messages")
                        .stream(primaryKey: ['id']).eq(
                            "chat_id",
                            value.generatechatId(value.getService.getLogin(),
                                value.receiver_id)),
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        return Padding(
                          padding: const EdgeInsets.only(left: 5, right: 5),
                          child: ListView.separated(
                            itemCount: snapshot.data?.length ?? 0,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              MesseagesModel messeagesModel =
                                  MesseagesModel.fromJson(snapshot.data?[index]
                                      as Map<String, dynamic>);
                              return Row(
                                mainAxisAlignment: messeagesModel.senderId ==
                                        value.getService.getLogin()
                                    ? MainAxisAlignment.end
                                    : MainAxisAlignment.start,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 10, horizontal: 10),
                                    decoration: BoxDecoration(
                                        color: Theme.of(context).primaryColor,
                                        borderRadius: BorderRadius.circular(5)),
                                    child: Text(
                                      messeagesModel.messagesText ?? "",
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            },
                            separatorBuilder:
                                (BuildContext context, int index) {
                              return const SizedBox(height: 10);
                            },
                          ),
                        );
                      } else {
                        return const CircularProgressIndicator();
                      }
                    }),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Row(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: TextFormField(
                            controller: value.chatController,
                            decoration: InputDecoration(
                                filled: true,
                                fillColor: Colors.grey.shade300,
                                hintText: "Enter Message",
                                suffixIcon: GestureDetector(
                                  onTap: () async {
                                    await value.addMessages();
                                  },
                                  child: Icon(Icons.send,
                                      color: Theme.of(context).primaryColor),
                                ),
                                border: InputBorder.none),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
