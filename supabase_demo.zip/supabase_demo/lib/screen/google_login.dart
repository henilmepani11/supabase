import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../supabase_constant_key.dart';

void main() async {
  // await dotenv.load();
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: SupabaseCredentials.apiUrl,
    anonKey: SupabaseCredentials.apiKey,
  );
  runApp(
    const GoogleLoginDemo(),
  );
}

class GoogleLoginDemo extends StatelessWidget {
  const GoogleLoginDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Supabase Google Login',
        home: HomeScreen());
  }
}

class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});

  final AuthController authController = Get.put(AuthController());

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AuthController>(
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('Supabase Google Login'),
          ),
          body: Center(
            child: ElevatedButton(
              onPressed: () async {
                await controller.signInWithGoogle();
              },
              child: const Text('Sign in with Google'),
            ),
          ),
        );
      },
    );
  }
}

class AuthController extends GetxController {
  // final supabase = SupabaseClient(
  //   dotenv.env[SupabaseCredentials.apiUrl]!,
  //   dotenv.env[SupabaseCredentials.apiKey]!,
  // );
  // String? clientId;
  // String? rawNonce;
  // String? accessToken;
  // String? idToken;
  final googleSignIn = GoogleSignIn(scopes: ['email']);

  Future<void> signInWithGoogle() async {
    try {
      final googleUser = await googleSignIn.signIn();
      if (googleUser == null) return; // User canceled the sign-in process

      final googleAuth = await googleUser.authentication;
      final response =
          await SupabaseCredentials.supabaseClient.auth.signInWithIdToken(
        captchaToken: googleAuth.accessToken, provider: Provider.google,
        idToken: googleAuth.idToken.toString(),

        // provider: 'google',
        // accessToken: googleAuth.accessToken,
        // idToken: googleAuth.idToken,
      );
      print(response);
    } catch (error) {
      print('Error signing in with Google: $error');
    }
  }

  // String _generateRandomString() {
  //   final random = Random.secure();
  //   return base64Url.encode(List<int>.generate(16, (_) => random.nextInt(256)));
  // }
  //
  // googleLogin() async {
  //   clientId =
  //       "383029002003-uuf9fucnc9he2116sdj7ic799caiu6er.apps.googleusercontent.com";
  //
  //   final redirectUrl = '${clientId?.split('.').reversed.join('.')}:/';
  //
  //   const discoveryUrl =
  //       'https://accounts.google.com/.well-known/openid-configuration';
  //
  //   rawNonce = _generateRandomString();
  //   final hashedNonce = sha256.convert(utf8.encode(rawNonce ?? '')).toString();
  //
  //   final result = await const FlutterAppAuth().authorize(
  //     AuthorizationRequest(
  //       clientId ?? "",
  //       redirectUrl,
  //       discoveryUrl: discoveryUrl,
  //       nonce: hashedNonce,
  //       scopes: [
  //         'openid',
  //         'email',
  //         'profile',
  //       ],
  //     ),
  //   );
  //
  //   if (result == null) {
  //     throw 'No result';
  //   }
  //   // final tokenResult = await const FlutterAppAuth().token(
  //   //   TokenRequest(
  //   //     clientId ?? "",
  //   //     redirectUrl,
  //   //     authorizationCode: result.authorizationCode,
  //   //     discoveryUrl: discoveryUrl,
  //   //     codeVerifier: result.codeVerifier,
  //   //     nonce: result.nonce,
  //   //     scopes: [
  //   //       'openid',
  //   //       'email',
  //   //     ],
  //   //   ),
  //   // );
  //
  //   final GoogleSignIn googleSignIn = GoogleSignIn(
  //     serverClientId: clientId,
  //     scopes: [
  //       'openid',
  //       'email',
  //     ],
  //   );
  //   final googleUser = await googleSignIn.signIn();
  //   final googleAuth = await googleUser!.authentication;
  //   accessToken = googleAuth.accessToken;
  //   idToken = googleAuth.idToken;
  //
  //   // accessToken = tokenResult?.accessToken;
  //   // idToken = tokenResult?.idToken;
  //
  //   accessToken = googleAuth.accessToken;
  //   idToken = googleAuth.idToken;
  //
  //   if (idToken == null) {
  //     throw 'No ID Token';
  //   }
  //   if (accessToken == null) {
  //     throw 'No Access Token';
  //   }
  //
  //   return SupabaseCredentials.supabaseClient.auth.signInWithIdToken(
  //     provider: Provider.google,
  //     idToken: idToken ?? '',
  //     accessToken: accessToken,
  //     nonce: rawNonce,
  //   );
  // }
}
