class TodoModel {
  int? id;
  String? name;
  String? createdAt;
  String? decription;
  String? imageUrl;

  TodoModel(
      {this.id, this.name, this.createdAt, this.decription, this.imageUrl});

  TodoModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    createdAt = json['created_at'];
    decription = json['decription'];
    imageUrl = json['image_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['created_at'] = createdAt;
    data['image_url'] = imageUrl;
    return data;
  }
}
