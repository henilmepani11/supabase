import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supa_practice_project/get_service.dart';
import 'package:supa_practice_project/screen/login_screen/view/login_screen.dart';
import 'package:supa_practice_project/service/auth_service.dart';
import 'package:supa_practice_project/supabase_constant_key.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class HomeProvider extends ChangeNotifier {
  TextEditingController nameController = TextEditingController();
  TextEditingController descripationController = TextEditingController();

  TextEditingController searchController = TextEditingController();

  AuthService authService = AuthService();
  GetService getService = GetService();

  Future<void> logOut(context) async {
    await authService.logOut();
    getService.box.remove("key");
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
        (route) => false);
    notifyListeners();
  }

  String searchValue = "";

  searchData(val) {
    searchValue = val;
    notifyListeners();
  }

  void addData(context, {id}) async {
    try {
      await Supabase.instance.client.from('todo').insert({
        'name': nameController.text,
        'decription': descripationController.text,
        'created_at': DateTime.now().toIso8601String(),
        "updated_at": DateTime.now().toIso8601String(),
        'id': int.tryParse(DateTime.now().millisecondsSinceEpoch.toString()),
        'user_id': id,
      });

      Navigator.pop(context);
      notifyListeners();
    } catch (e) {
      print("add data :$e");
    }
  }

  void editData(context, {id}) async {
    try {
      await SupabaseCredentials.supabaseClient.from('todo').update(
        {
          'name': nameController.text,
          'decription': descripationController.text,
          "updated_at": DateTime.now().toIso8601String(),
        },
      ).match({"id": id});

      Navigator.pop(context);
      notifyListeners();
    } catch (e) {
      print("edit data :$e");
    }
  }

  Future<void> deleteData({id}) async {
    await SupabaseCredentials.supabaseClient
        .from('todo')
        .delete()
        .match({'id': id});

    notifyListeners();
  }

  Future<void> picImage({id, String? deleteImageUrl}) async {
    try {
      XFile? imageFile =
          await ImagePicker().pickImage(source: ImageSource.gallery);
      if (imageFile != null) {
        final avatarFile = File(imageFile.path);
        if (deleteImageUrl != null) {
          await SupabaseCredentials.supabaseClient.storage
              .from('images')
              .remove([deleteImageUrl.split("/").last]);
        }

        String path = await SupabaseCredentials.supabaseClient.storage
            .from('images')
            .upload(
              imageFile.name,
              avatarFile,
              fileOptions:
                  const FileOptions(cacheControl: '3600', upsert: false),
            );

        var splitpath = path.toString().split("/").last;

        final res = SupabaseCredentials.supabaseClient.storage
            .from('images')
            .getPublicUrl(splitpath);

        await SupabaseCredentials.supabaseClient.from('todo').upsert({
          'id': id,
          'image_url': res,
          'created_at': DateTime.now().toIso8601String(),
        });

        notifyListeners();
      }
    } catch (e) {
      print("picImage : $e");
    }
  }
}
