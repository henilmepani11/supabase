import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supa_practice_project/constant.dart';
import 'package:supa_practice_project/dialog.dart';
import 'package:supa_practice_project/screen/chat_screen/view/chat_screen.dart';
import 'package:supa_practice_project/screen/home_screen/model.dart';
import 'package:supa_practice_project/screen/home_screen/provider/home_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Consumer<HomeProvider>(
      builder: (context, value, child) {
        var userId = value.getService.getLogin();
        return GestureDetector(
          onTap: () {
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            appBar: AppBar(
              title: const Text("Home Screen"),
              centerTitle: true,
              actions: [
                IconButton(
                    onPressed: () {
                      myDialog(
                        value: value,
                        isAdd: true,
                        context: context,
                        userId: userId,
                        descripation: value.descripationController,
                        name: value.nameController,
                      );
                    },
                    icon: const Icon(Icons.add)),
                IconButton(
                    onPressed: () async {
                      await value.logOut(context);
                    },
                    icon: const Icon(Icons.logout)),
                IconButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const ChatScreen()));
                    },
                    icon: const Icon(Icons.arrow_circle_right)),
              ],
            ),
            body: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    onChanged: (val) {
                      value.searchData(val);
                    },
                    controller: value.searchController,
                    decoration: InputDecoration(
                      hintText: "Enter Search text",
                      focusedBorder: MyBorder.outlineInputBorder,
                      border: MyBorder.outlineInputBorder,
                    ),
                  ),
                ),
                FutureBuilder(
                  future: Supabase.instance.client
                      .from('todo')
                      .select<List<Map<String, dynamic>>>()
                      .eq('user_id', userId)
                      .like('name', "%${value.searchValue}%")
                      .order('created_at'),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    return snapshot.data!.isNotEmpty
                        ? ListView.builder(
                            shrinkWrap: true,
                            itemCount: snapshot.data?.length ?? 0,
                            itemBuilder: (context, index) {
                              TodoModel todoModel = TodoModel.fromJson(snapshot
                                  .data?[index] as Map<String, dynamic>);

                              return ListTile(
                                leading: GestureDetector(
                                    onTap: () async {
                                      await value.picImage(
                                          id: todoModel.id,
                                          deleteImageUrl: todoModel.imageUrl);
                                    },
                                    child: CircleAvatar(
                                      radius: 23,
                                      backgroundImage:
                                          todoModel.imageUrl != null
                                              ? NetworkImage(
                                                  todoModel.imageUrl ?? "")
                                              : null,
                                    )),
                                title: Text(todoModel.name ?? ""),
                                subtitle: Text(todoModel.decription ?? ""),
                                trailing: Wrap(
                                  spacing: 12,
                                  children: [
                                    IconButton(
                                        onPressed: () {
                                          value.nameController.text =
                                              todoModel.name.toString();
                                          value.descripationController.text =
                                              todoModel.decription.toString();
                                          myDialog(
                                              value: value,
                                              isAdd: false,
                                              context: context,
                                              descripation:
                                                  value.descripationController,
                                              name: value.nameController,
                                              id: todoModel.id);
                                        },
                                        icon: const Icon(Icons.edit)),
                                    IconButton(
                                        onPressed: () async {
                                          await value.deleteData(
                                              id: todoModel.id);
                                        },
                                        icon: const Icon(Icons.delete)),
                                  ],
                                ),
                              );
                            },
                          )
                        : const Center(child: Text("No Notes"));
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
