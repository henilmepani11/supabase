import 'package:flutter/material.dart';
import 'package:supa_practice_project/get_service.dart';
import 'package:supa_practice_project/screen/home_screen/view/home_screen.dart';
import 'package:supa_practice_project/service/auth_service.dart';
import 'package:supa_practice_project/supabase_constant_key.dart';
import 'package:supa_practice_project/toast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class LoginProvider extends ChangeNotifier {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  AuthService authService = AuthService();
  bool isLoader = false;

  GetService getService = GetService();

  void setLoader(val) {
    isLoader = val;
    notifyListeners();
  }

  fun() async {
    final res = await SupabaseCredentials.supabaseClient.functions
        .invoke('hello', body: {'foo': 'baa'});
    final data = res.data;
  }

  Future<AuthResponse?> loginIn(context) async {
    try {
      if (emailController.text.isNotEmpty &&
          passwordController.text.isNotEmpty) {
        setLoader(true);
        AuthResponse response = await authService.loginIn(
            emailController.text, passwordController.text);

        if (response.user != null) {
          print(response.user?.email);

          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomeScreen()),
              (route) => false);
          getService.setLogin(response.user?.id);

          toast("Login successfully");
        }
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text("Both field requried")));
      }
    } on AuthException catch (e) {
      toast(e.message);
    } finally {
      setLoader(false);
    }
  }

  void setField() {
    emailController.clear();
    passwordController.clear();
  }
}
