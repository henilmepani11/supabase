import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supa_practice_project/constant.dart';
import 'package:supa_practice_project/screen/login_screen/provider/login_provider.dart';
import 'package:supa_practice_project/screen/signup_screen/view/sign_up_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  void initState() {
    Provider.of<LoginProvider>(context, listen: false).setField();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    LoginProvider loginProvider =
        Provider.of<LoginProvider>(context, listen: false);
    return Consumer<LoginProvider>(
      builder: (context, value, child) => Scaffold(
        appBar: AppBar(title: const Text("Login Screen"), centerTitle: true),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                controller: loginProvider.emailController,
                decoration: InputDecoration(
                  hintText: "Enter Email Address",
                  focusedBorder: MyBorder.outlineInputBorder,
                  border: MyBorder.outlineInputBorder,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                controller: loginProvider.passwordController,
                decoration: InputDecoration(
                  hintText: "Enter Password",
                  focusedBorder: MyBorder.outlineInputBorder,
                  border: MyBorder.outlineInputBorder,
                ),
              ),
            ),
            ElevatedButton(
                onPressed: () async {
                  await loginProvider.loginIn(context);
                },
                child: loginProvider.isLoader
                    ? const CircularProgressIndicator(
                        backgroundColor: Colors.white)
                    : const Text("Login")),
            const SizedBox(height: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("Not account? "),
                GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const SignUpScreen()));

                      loginProvider.setField();
                    },
                    child: const Text(
                      "SignUp",
                      style: TextStyle(decoration: TextDecoration.underline),
                    )),
              ],
            )
          ],
        ),
      ),
    );
  }
}
