import 'package:flutter/material.dart';
import 'package:supa_practice_project/get_service.dart';
import 'package:supa_practice_project/screen/home_screen/view/home_screen.dart';
import 'package:supa_practice_project/service/auth_service.dart';
import 'package:supa_practice_project/toast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SignUpProvider extends ChangeNotifier {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  AuthService authService = AuthService();
  bool isLoader = false;

  GetService getService = GetService();

  setLoader(val) {
    isLoader = val;
    notifyListeners();
  }

  Future<AuthResponse?> signUp(context) async {
    try {
      if (emailController.text.isNotEmpty &&
          passwordController.text.isNotEmpty) {
        setLoader(true);
        AuthResponse response = await authService.signUp(
            emailController.text, passwordController.text);

        if (response.user != null) {

          print(response.user?.email);
          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomeScreen()),
              (route) => false);

          getService.setLogin(response.user?.id);
          toast("Sign up successfully");
        }
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text("Both field requried")));
      }
    } on AuthException catch (e) {
      toast(e.message);
    } finally {
      setLoader(false);
    }
  }
}
