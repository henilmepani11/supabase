import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supa_practice_project/constant.dart';
import 'package:supa_practice_project/screen/signup_screen/provider/signup_provider.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  @override
  Widget build(BuildContext context) {
    SignUpProvider signUpProvider =
        Provider.of<SignUpProvider>(context, listen: false);
    return Consumer<SignUpProvider>(
      builder: (context, value, child) => Scaffold(
        appBar: AppBar(title: const Text("Signup Screen"), centerTitle: true),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                controller: signUpProvider.emailController,
                decoration: InputDecoration(
                  hintText: "Enter Email Address",
                  focusedBorder: MyBorder.outlineInputBorder,
                  border: MyBorder.outlineInputBorder,
                ),
              ),
            ),
            
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                controller: signUpProvider.passwordController,
                decoration: InputDecoration(
                  hintText: "Enter Password",
                  focusedBorder: MyBorder.outlineInputBorder,
                  border: MyBorder.outlineInputBorder,
                ),
              ),
            ),
            ElevatedButton(
                onPressed: () async {
                  await signUpProvider.signUp(context);
                },
                child: signUpProvider.isLoader
                    ? const CircularProgressIndicator(
                        backgroundColor: Colors.white)
                    : const Text("Sign Up"))
          ],
        ),
      ),
    );
  }
}
