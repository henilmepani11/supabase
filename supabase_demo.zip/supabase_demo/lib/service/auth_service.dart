import 'package:supa_practice_project/supabase_constant_key.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  Future<AuthResponse> signUp(email, password) async {
    AuthResponse response =
        await SupabaseCredentials.supabaseClient.auth.signUp(
      email: email,
      password: password,
    );
    return response;
  }

  Future<AuthResponse> loginIn(email, password) async {
    AuthResponse response =
        await SupabaseCredentials.supabaseClient.auth.signInWithPassword(
      email: email,
      password: password,
    );
    return response;
  }

  logOut() async {
    try {
      await SupabaseCredentials.supabaseClient.auth.signOut();
    } on AuthException catch (e) {
      print(e.message);
    }
  }
}
