import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseCredentials {
  static String apiKey =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFxa3hwYmJmdnd2bm5id3dyY2JrIiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTY2NjQwODQsImV4cCI6MjAxMjI0MDA4NH0.LU7E2NQra910tXr2H3vQFjwIW4oRM43RsS7HCad1zWo";
  static String apiUrl = "https://aqkxpbbfvwvnnbwwrcbk.supabase.co";

  static SupabaseClient supabaseClient = SupabaseClient(apiUrl, apiKey);
}
